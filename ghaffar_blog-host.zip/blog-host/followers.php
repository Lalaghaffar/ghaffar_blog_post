<?php
// session_start();
require_once 'utilities/blogposts.php';
require_once 'utilities/user.php';

	if (!is_user_loggedin()) {
		header("Location: index.php");
		return;
	}

	if(isset($_GET['id'])) {
		$post_id = $_GET['id'];
	}
	if(isset($_SESSION['_user'])){
	$user_id = $_SESSION['_user']['user_id'];
	 // print_r($user_id);   
	}
	$alreadyInserted = follow($post_id,$user_id);
	if($alreadyInserted == 1){
	header("Location: home.php");
	$_SESSION['flash_message'] = 'Already Following ';
	$_SESSION['flash_type'] = 'success'; 
	}else{
	header("Location: home.php");
		$_SESSION['flash_message'] = 'Followed Successfull';
	$_SESSION['flash_type'] = 'success'; 

	}
?>

